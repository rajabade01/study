import { useState } from "react";
import { loginUser } from "../services/authService";

function LoginForm({ onLoginSuccess }) {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [message, setMessage] = useState("");
    const [isError, setIsError] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    const handleLogin = async (event) => {
        event.preventDefault();

        setMessage("");
        setIsError(false);

        if (!username || !password) {
            setMessage("Please enter username and password.");
            setIsError(true);
            return;
        }

        try {
            setIsLoading(true);

            console.log("Calling login API...");

            const response = await loginUser(username, password);

            console.log("Login response:", response);

            if (response.success === true) {
                setMessage("Successfully logged in");
                onLoginSuccess();
            } else {
                setMessage(response.message || "Login failed");
                setIsError(true);
            }
        } catch (error) {
            console.error("Login error:", error);

            if (error.response) {
                setMessage(
                    error.response.data?.message ||
                    "Login failed"
                );
            } else if (error.request) {
                setMessage("Unable to connect to the server.");
            } else {
                setMessage(error.message);
            }

            setIsError(true);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="login-card">
            <h1>Helix</h1>
            <h2>Login</h2>

            <form onSubmit={handleLogin}>
                <div className="form-group">
                    <label htmlFor="username">Username</label>

                    <input
                        id="username"
                        type="text"
                        value={username}
                        onChange={(event) =>
                            setUsername(event.target.value)
                        }
                        placeholder="Enter username"
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="password">Password</label>

                    <input
                        id="password"
                        type="password"
                        value={password}
                        onChange={(event) =>
                            setPassword(event.target.value)
                        }
                        placeholder="Enter password"
                    />
                </div>

                <button type="submit" disabled={isLoading}>
                    {isLoading ? "Logging in..." : "Login"}
                </button>
            </form>

            {message && (
                <p className={isError ? "error-message" : "success-message"}>
                    {message}
                </p>
            )}
        </div>
    );
}

export default LoginForm;