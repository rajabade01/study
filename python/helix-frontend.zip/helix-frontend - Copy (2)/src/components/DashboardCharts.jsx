import {
    LineChart,
    Line,
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer
} from "recharts";

function DashboardCharts({ charts }) {

    if (!charts) {
        return null;
    }

    return (
        <section className="dashboard-section">

            <h2>Analytics</h2>

            <div className="charts-container">

                {/* User Registration Chart */}
                {charts.user_registrations && (
                    <div className="chart-card">

                        <h3>
                            {charts.user_registrations.title}
                        </h3>

                        <ResponsiveContainer
                            width="100%"
                            height={300}
                        >
                            <LineChart
                                data={
                                    charts.user_registrations.data
                                }
                            >
                                <CartesianGrid strokeDasharray="3 3" />

                                <XAxis dataKey="month" />

                                <YAxis />

                                <Tooltip />

                                <Line
                                    type="monotone"
                                    dataKey="users"
                                    stroke="#2563eb"
                                    strokeWidth={3}
                                />
                            </LineChart>
                        </ResponsiveContainer>

                    </div>
                )}

                {/* Projects Chart */}
                {charts.projects && (
                    <div className="chart-card">

                        <h3>
                            {charts.projects.title}
                        </h3>

                        <ResponsiveContainer
                            width="100%"
                            height={300}
                        >
                            <BarChart
                                data={charts.projects.data}
                            >
                                <CartesianGrid strokeDasharray="3 3" />

                                <XAxis dataKey="category" />

                                <YAxis />

                                <Tooltip />

                                <Bar
                                    dataKey="projects"
                                    fill="#16a34a"
                                />
                            </BarChart>
                        </ResponsiveContainer>

                    </div>
                )}

            </div>

        </section>
    );
}

export default DashboardCharts;