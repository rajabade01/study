import axios from "axios";

const API_URL = "http://localhost:5000/api";

export const loginUser = async (username, password) => {
    const response = await axios.post(
        `${API_URL}/login`,
        {
            username,
            password
        }
    );

    console.log("Login API status:", response.status);
    console.log("Login API response:", response.data);

    return response.data;
};