import axios from "axios";

const API_URL = "http://localhost:5000/api";

export const getDashboardData = async () => {
    const response = await axios.get(
        `${API_URL}/dashboard`
    );

    console.log("Dashboard API status:", response.status);
    console.log("Dashboard API data:", response.data);

    return response.data;
};