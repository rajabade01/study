import LoginForm from "../components/LoginForm";

function Login({ onLoginSuccess }) {
    return (
        <div className="login-page">
            <LoginForm onLoginSuccess={onLoginSuccess} />
        </div>
    );
}

export default Login;