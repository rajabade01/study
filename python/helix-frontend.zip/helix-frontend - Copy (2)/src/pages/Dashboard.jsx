import { useEffect, useState } from "react";
import { getDashboardData } from "../services/dashboardService";
import DashboardCharts from "../components/DashboardCharts";

function Dashboard() {
    const [showProfile, setShowProfile] = useState(false);

    const [dashboardData, setDashboardData] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState("");

    // Controls which Quick Action popup is displayed
    const [activePopup, setActivePopup] = useState(null);

    const handleLogout = () => {
        window.location.reload();
    };

    /*
     * Load dashboard data from Flask API
     */
    useEffect(() => {
        const loadDashboardData = async () => {
            try {
                setIsLoading(true);
                setError("");

                const response = await getDashboardData();

                console.log("Dashboard response:", response);

                if (response.success === true) {
                    setDashboardData(response.data);
                } else {
                    setError(
                        response.message ||
                        "Unable to load dashboard data."
                    );
                }
            } catch (error) {
                console.error("Dashboard API error:", error);

                if (error.response) {
                    setError(
                        error.response.data?.message ||
                        "Unable to load dashboard data."
                    );
                } else if (error.request) {
                    setError("Unable to connect to the server.");
                } else {
                    setError(error.message);
                }
            } finally {
                setIsLoading(false);
            }
        };

        loadDashboardData();
    }, []);

    /*
     * Open Quick Action popup
     */
    const handleQuickAction = (action) => {
        setActivePopup(action);
    };

    /*
     * Close Quick Action popup
     */
    const closePopup = () => {
        setActivePopup(null);
    };

    /*
     * Loading state
     */
    if (isLoading) {
        return (
            <div className="dashboard">
                <div className="dashboard-content">
                    <h2>Loading dashboard...</h2>
                </div>
            </div>
        );
    }

    /*
     * Error state
     */
    if (error) {
        return (
            <div className="dashboard">
                <div className="dashboard-content">
                    <h2>Dashboard Error</h2>

                    <p className="error-message">
                        {error}
                    </p>
                </div>
            </div>
        );
    }

    /*
     * No dashboard data
     */
    if (!dashboardData) {
        return null;
    }

    return (
        <div className="dashboard">

            {/* =====================================================
                Header
            ====================================================== */}
            <header className="dashboard-header">

                <div className="header-left">
                    <h1>Helix</h1>
                    <span>Dashboard</span>
                </div>

                <div className="header-right">

                    <span className="welcome-text">
                        Welcome, Admin
                    </span>

                    <button
                        className="profile-button"
                        onClick={() =>
                            setShowProfile(!showProfile)
                        }
                    >
                        A
                    </button>

                    <button
                        className="logout-button"
                        onClick={handleLogout}
                    >
                        Logout
                    </button>

                </div>

            </header>


            {/* =====================================================
                Main Content
            ====================================================== */}
            <main className="dashboard-content">

                {/* Welcome */}
                <section className="welcome-section">

                    <h2>
                        {dashboardData.welcome_message} 👋
                    </h2>

                    <p>
                        {dashboardData.description}
                    </p>

                </section>


                {/* Summary Cards */}
                <section className="summary-cards">

                    {dashboardData.summary.map(
                        (item, index) => (
                            <div
                                className="dashboard-card"
                                key={index}
                            >

                                <h3>
                                    {item.title}
                                </h3>

                                <p className="card-number">
                                    {item.value}
                                </p>

                                <span>
                                    {item.description}
                                </span>

                            </div>
                        )
                    )}

                </section>


                {/* Charts */}
                <DashboardCharts
                    charts={dashboardData.charts}
                />


                {/* =================================================
                    Quick Actions
                ================================================== */}
                <section className="dashboard-section">

                    <h2>
                        Quick Actions
                    </h2>

                    <div className="quick-actions">

                        {dashboardData.quick_actions.map(
                            (action, index) => (

                                <button
                                    className="action-card"
                                    key={index}
                                    onClick={() =>
                                        handleQuickAction(
                                            action.title
                                        )
                                    }
                                >

                                    <strong>
                                        {action.title}
                                    </strong>

                                    <span>
                                        {action.description}
                                    </span>

                                </button>

                            )
                        )}

                    </div>

                </section>


                {/* =================================================
                    Recent Activity
                ================================================== */}
                <section className="dashboard-section">

                    <h2>
                        Recent Activity
                    </h2>

                    <div className="activity-list">

                        {dashboardData.recent_activity.map(
                            (activity, index) => (

                                <div
                                    className="activity-item"
                                    key={index}
                                >

                                    <div>

                                        <strong>
                                            {activity.title}
                                        </strong>

                                        <p>
                                            {activity.description}
                                        </p>

                                    </div>

                                    <span>
                                        {activity.time}
                                    </span>

                                </div>

                            )
                        )}

                    </div>

                </section>


                {/* =================================================
                    Profile
                ================================================== */}
                {showProfile && (
                    <section className="profile-panel">

                        <h2>
                            Profile
                        </h2>

                        <p>
                            <strong>Username:</strong> admin
                        </p>

                        <p>
                            <strong>Role:</strong> Administrator
                        </p>

                        <p>
                            <strong>Status:</strong> Active
                        </p>

                    </section>
                )}

            </main>


            {/* =====================================================
                QUICK ACTION POPUPS
            ====================================================== */}

            {activePopup && (
                <div
                    className="popup-overlay"
                    onClick={closePopup}
                >

                    <div
                        className="popup-card"
                        onClick={(event) =>
                            event.stopPropagation()
                        }
                    >

                        {/* =================================================
                            Popup Header
                        ================================================== */}
                        <div className="popup-header">

                            <h2>
                                {activePopup}
                            </h2>

                            <button
                                className="popup-close"
                                onClick={closePopup}
                            >
                                ×
                            </button>

                        </div>


                        {/* =================================================
                            Add User
                        ================================================== */}
                        {activePopup === "Add User" && (

                            <div className="popup-content">

                                <p>
                                    Create a new Helix user.
                                </p>

                                <div className="popup-form-group">

                                    <label>
                                        Full Name
                                    </label>

                                    <input
                                        type="text"
                                        placeholder="Enter full name"
                                    />

                                </div>


                                <div className="popup-form-group">

                                    <label>
                                        Username
                                    </label>

                                    <input
                                        type="text"
                                        placeholder="Enter username"
                                    />

                                </div>


                                <div className="popup-form-group">

                                    <label>
                                        Email
                                    </label>

                                    <input
                                        type="email"
                                        placeholder="Enter email"
                                    />

                                </div>


                                <div className="popup-form-group">

                                    <label>
                                        Role
                                    </label>

                                    <select>

                                        <option>
                                            Administrator
                                        </option>

                                        <option>
                                            Developer
                                        </option>

                                        <option>
                                            Tester
                                        </option>

                                        <option>
                                            Viewer
                                        </option>

                                    </select>

                                </div>


                                <div className="popup-actions">

                                    <button
                                        className="popup-secondary-button"
                                        onClick={closePopup}
                                    >
                                        Cancel
                                    </button>

                                    <button
                                        className="popup-primary-button"
                                        onClick={() =>
                                            alert(
                                                "Dummy user created successfully!"
                                            )
                                        }
                                    >
                                        Create User
                                    </button>

                                </div>

                            </div>

                        )}


                        {/* =================================================
                            View Users
                        ================================================== */}
                        {activePopup === "View Users" && (

                            <div className="popup-content">

                                <p>
                                    List of registered Helix users.
                                </p>

                                <table className="users-table">

                                    <thead>

                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Username</th>
                                            <th>Role</th>
                                            <th>Status</th>
                                        </tr>

                                    </thead>

                                    <tbody>

                                        <tr>
                                            <td>1</td>
                                            <td>Raj</td>
                                            <td>raj</td>
                                            <td>Administrator</td>
                                            <td>Active</td>
                                        </tr>

                                        <tr>
                                            <td>2</td>
                                            <td>John Smith</td>
                                            <td>john</td>
                                            <td>Developer</td>
                                            <td>Active</td>
                                        </tr>

                                        <tr>
                                            <td>3</td>
                                            <td>Priya</td>
                                            <td>priya</td>
                                            <td>Tester</td>
                                            <td>Active</td>
                                        </tr>

                                        <tr>
                                            <td>4</td>
                                            <td>Alex</td>
                                            <td>alex</td>
                                            <td>Viewer</td>
                                            <td>Inactive</td>
                                        </tr>

                                    </tbody>

                                </table>

                                <div className="popup-actions">

                                    <button
                                        className="popup-secondary-button"
                                        onClick={closePopup}
                                    >
                                        Close
                                    </button>

                                </div>

                            </div>

                        )}


                        {/* =================================================
                            Projects
                        ================================================== */}
                        {activePopup === "Projects" && (

                            <div className="popup-content">

                                <p>
                                    Current Helix projects.
                                </p>

                                <div className="project-list">

                                    <div className="project-item">

                                        <div>
                                            <strong>
                                                Helix Platform
                                            </strong>

                                            <p>
                                                Student management
                                                platform.
                                            </p>
                                        </div>

                                        <span className="project-status-active">
                                            Active
                                        </span>

                                    </div>


                                    <div className="project-item">

                                        <div>
                                            <strong>
                                                Automation Framework
                                            </strong>

                                            <p>
                                                Python based test
                                                automation framework.
                                            </p>
                                        </div>

                                        <span className="project-status-active">
                                            Active
                                        </span>

                                    </div>


                                    <div className="project-item">

                                        <div>
                                            <strong>
                                                AI Assistant
                                            </strong>

                                            <p>
                                                AI powered learning
                                                assistant.
                                            </p>
                                        </div>

                                        <span className="project-status-planned">
                                            Planned
                                        </span>

                                    </div>

                                </div>


                                <div className="popup-actions">

                                    <button
                                        className="popup-secondary-button"
                                        onClick={closePopup}
                                    >
                                        Close
                                    </button>

                                </div>

                            </div>

                        )}

                    </div>

                </div>
            )}

        </div>
    );
}

export default Dashboard;