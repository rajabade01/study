// props -- properties --- function parameters
// states -- parameter/ function scope
// events -- click, mouse, type, submit
import { useState } from "react";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import "./App.css";

function App() {
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    const handleLoginSuccess = () => {
        console.log("Login successful - loading dashboard");
        setIsLoggedIn(true);
    };

    console.log("App isLoggedIn:", isLoggedIn);

    if (isLoggedIn) {
        return <Dashboard />;
    }

    return (
        <Login onLoginSuccess={handleLoginSuccess} />
    );
}

export default App;


//An event happens → React calls a function → the function changes state or performs an action → React updates the UI.
// Clicking a button       → onClick
// Typing in an input      → onChange
// Submitting a form       → onSubmit
// Moving mouse            → onMouseMove
// Mouse entering element  → onMouseEnter
// Checkbox changed        → onChange
// Keyboard key pressed   → onKeyDown